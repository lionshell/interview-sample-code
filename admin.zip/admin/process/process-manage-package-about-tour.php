<?php
include_once("../control/PackageControlDetail.php");
include("process-image-upload.php");
$PackageControlDetail = new PackageControlDetail();

if(isset($_POST['save'])){
	$pdcode = $_POST['pdcode'];
	$i=0;
	foreach($pdcode as $p){
		$pdcode = $_POST['pdcode'][$i];
		$placecoverd = htmlspecialchars($_POST['placecoverd'][$i],ENT_QUOTES);
		$inclusions = htmlspecialchars($_POST['inclusions'][$i],ENT_QUOTES);
		$exclustions = htmlspecialchars($_POST['exclustions'][$i],ENT_QUOTES);
		$eventdate = $_POST['eventdate'][$i];
		if($_POST['placecoverd'][$i] != '' || $_POST['inclusions'][$i] != '' || $_POST['exclustions'][$i] != ''){	
			$pakAbtDetCode = $PackageControlDetail->insertAboutCtrl($placecoverd, $inclusions, $exclustions, $eventdate, $pdcode);
			$i++;
		}
		
	}
	if($i != 0){
		echo '<script>window.location = "../manage-detailded-day-wise-itinerary?pdcode='.$pdcode.'";</script>';
	}else{	
		echo '<script>window.location = "../manage-package-about-tour?pdcode='.$pdcode.'";</script>';
	}
	/* 
	$fileIndexBanner = $_FILES['packagebannerimg'];
	$folderBanner =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/";
	$folderBannerView = "images/banner";
	$folderBanner .= $folderBannerView;
	$folderBannerPath = ImgUpload($fileIndexBanner, $title, $folderBanner);
	$cover_img_path = $folderBannerView."/".$folderBannerPath;
	
	$fileIndexProfile = $_FILES['packageprofileimg'];
	$folderProfile =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/";
	$folderProfileView = "images/profile";
	$folderProfile .= $folderProfileView;
	$folderBannerProfile = ImgUpload($fileIndexProfile, $title, $folderProfile);
	$profile_img_path = $folderProfileView."/".$folderBannerProfile;
	 */
	/* if($pakAbtDetCode){
		echo '<script>window.location = "../manage-detailded-day-wise-itinerary?pdcode='.$pdcode.'";</script>';
	} */ 
}
?>