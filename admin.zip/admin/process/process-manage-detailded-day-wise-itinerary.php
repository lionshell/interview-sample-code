<?php
 include_once("../control/PackageControlDetail.php");
//include("process-image-upload.php");
$PackageControlDetail = new PackageControlDetail();

if(isset($_POST['save'])){
	$pdcode = $_POST['pdcode'];
	$i=0;
	foreach($pdcode as $p){
		$pdcode = $_POST['pdcode'][$i];
		$heading = htmlspecialchars($_POST['heading'][$i],ENT_QUOTES);
		$description = htmlspecialchars($_POST['description'][$i],ENT_QUOTES);
		if($_POST['heading'][$i] != '' || $_POST['description'][$i]){	
			$pakDetDayCode = $PackageControlDetail->insertDetailDayCtrl($heading, $description, $pdcode);		
			$i++;
		}
	}
	if($i != 0){
		echo '<script>window.location = "../manage-gallery?pdcode='.$pdcode.'";</script>';
	}else{
		echo '<script>window.location = "../manage-detailded-day-wise-itinerary?pdcode='.$pdcode.'";</script>';
	}
}
?>