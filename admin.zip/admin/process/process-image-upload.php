<?php
/* 
=========================
Example usage
=========================

$fileIndexBanner = $_FILES['packagebannerimg'];  //  name. 
$folderBanner =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/"; // root directory.
$folderBannerView = "images/banner"; // location to store in db except root directory.
$folderBanner .= $folderBannerView; // location where file store.
$folderBannerPath = ImgUpload($fileIndexBanner, $title, $folderBanner); // function usage.
$cover_img_path = $folderBannerView."/".$folderBannerPath; // String variable send to db contains of path.

=========================
 */

function ImgUpload($fileIndex = "", $title = "", $folder = ""){
	$img_path_type = $fileIndex['type'];
	$img_path_tempname = $fileIndex['tmp_name'];
	$img_path_name = $fileIndex['name'];
	$img_path_new_name = strtolower(str_replace(' ', '-', $title));
	$img_path_new_name = strtolower(str_replace('/', '-', $img_path_new_name));
	$img_path_ext = pathinfo($img_path_name, PATHINFO_EXTENSION);
	$img_path_new_name_store_db = "$img_path_new_name.$img_path_ext";
	move_uploaded_file($img_path_tempname, "$folder/$img_path_new_name.$img_path_ext");	
	return $img_path_new_name_store_db;
}

function ImgMultipleUpload($fileIndex = "", $title = "", $folder = "", $i = ""){
	$imgNum = $i+1;
	$img_path_type = $fileIndex['type'][$i];
	$img_path_tempname = $fileIndex['tmp_name'][$i];
	$img_path_name = $fileIndex['name'][$i];
	$img_path_new_name = strtolower(str_replace(' ', '-', $title));
	$img_path_new_name = strtolower(str_replace('/', '-', $img_path_new_name));
	$img_path_ext = pathinfo($img_path_name, PATHINFO_EXTENSION);
	$img_path_new_name_store_db = "$img_path_new_name-$imgNum.$img_path_ext";
	move_uploaded_file($img_path_tempname, "$folder/$img_path_new_name-$imgNum.$img_path_ext");	
	return $img_path_new_name_store_db;
}

?>