<?php
session_start();
include_once('../control/SystemUserAuthControl.php');
$SystemUserAuthControl = new SystemUserAuthControl();
$e = $SystemUserAuthControl->logout();
	echo '<script>window.location = "../log-in";</script>';
?>