<?php
session_start();
$usr = $_POST['usr'];
$pwd = $_POST['pwd'];
include_once('../control/SystemUserAuthControl.php');
$SystemUserAuthControl = new SystemUserAuthControl();
$e = $SystemUserAuthControl->athourize($usr,$pwd);
if($e[0] === 1){
	$_SESSION['username'] = $e[1];
	echo '<script>window.location = ".././";</script>';
}else{
	echo '<script>window.location = "../log-in";</script>';
}


?>