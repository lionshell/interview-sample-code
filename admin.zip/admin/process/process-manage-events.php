<?php
/*
Manage events
*/
?>