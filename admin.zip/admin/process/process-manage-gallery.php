<?php
include_once("../control/PackageControlDetail.php");
include("process-image-upload.php");
$PackageControlDetail = new PackageControlDetail();

if(isset($_POST['save'])){
	$pdcode = $_POST['pdcode'];
	$title = $PackageControlDetail->getTitle($pdcode);
	$i = 0;
	$folderProfile =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/";
	$folderProfileView = "images/gallery/$pdcode";
	$folderName = $folderProfile.$folderProfileView;
	 if (!file_exists($folderName)) {
		mkdir($folderName, 0777, true);		
	}
	foreach($_FILES['gallery']['name'] as $gallery){
		$fileIndexProfile = $_FILES['gallery'];
		$folderProfile .= $folderProfileView;
		$folderBannerProfile = ImgMultipleUpload($fileIndexProfile, $title, $folderName,$i);
		$profile_img_path = $folderProfileView."/".$folderBannerProfile;
		if($folderBannerProfile){
			$PackageControlDetail->insertGalleryCtrl($profile_img_path, $pdcode);
			$i++;
		}
	} 
	if($i != 0){
		echo '<script>window.location = "../manage-package";</script>';
	}else{
		echo '<script>window.location = "../manage-gallery?pdcode='.$pdcode.'";</script>';
	}
}
?>