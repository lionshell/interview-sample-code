<?php
include_once('../control/PackageControlCat.php');
$ctrl = new PackageControlCat;
if(isset($_POST['saveCat'])) {
    $cat_type = $_POST['cat_type'];
    $title = $_POST['cat_title'];
    $decr = $_POST['cat_desc'];
    $img_path_type = $_FILES['cat_cover_img']['type'];
    $img_path_tempname = $_FILES['cat_cover_img']['tmp_name'];
    $img_path_name = $_FILES['cat_cover_img']['name'];
    $img_path_new_name = strtolower(str_replace(' ', '-', $title));
    $img_path_ext = pathinfo($img_path_name, PATHINFO_EXTENSION);
    $img_path_new_name_store_db = "$cat_type-$img_path_new_name.$img_path_ext";
    $folder =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle";
    $folder .= "/images/cat-cover-img";
    move_uploaded_file($img_path_tempname, "$folder/$cat_type-$img_path_new_name.$img_path_ext");
    $ctrl->insertCtrl($cat_type, $title, $decr, $img_path_new_name_store_db);
	echo '<script>window.location = "../manage-package-cat?cat=std";</script>';
	//header("Location: ../manage-package-cat?cat=std");	
}
if(isset($_GET['del'])) {
    $id = $_GET['id'];
	$ctrl->delCtrl($id, $pageCat);
	echo '<script>window.location = "../manage-package-cat?cat=std";</script>';
}
?>