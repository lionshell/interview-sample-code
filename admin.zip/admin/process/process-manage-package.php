<?php
include_once("../control/PackageControlDetail.php");
include("process-image-upload.php");
$PackageControlDetail = new PackageControlDetail();

if(isset($_POST['save'])){
	$title = $_POST['packagename'];
	$short_decr = htmlspecialchars($_POST['packageshortdescription'],ENT_QUOTES);
	$start_date = $_POST['packagestartdate'];
	$end_date = $_POST['packageenddate'];
	$available_seats = $_POST['packageavalibleseats'];
	$duration = $_POST['packageduration'];
	$price = $_POST['packageprice'];
	$promotion_price = $_POST['packagepromotionprice'];
	$deep_desc = htmlspecialchars($_POST['packagedescription'],ENT_QUOTES);
	$featured_video_link = $_POST['packagefeaturedvideolink'];
	$google_map_link = $_POST['packagemaplink'];
	$package_cat_id = $_POST['packagecat'];
	//echo $package_cat_id;
	
	$fileIndexBanner = $_FILES['packagebannerimg'];
	$folderBanner =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/";
	$folderBannerView = "images/banner";
	$folderBanner .= $folderBannerView;
	$folderBannerPath = ImgUpload($fileIndexBanner, $title, $folderBanner);
	$cover_img_path = $folderBannerView."/".$folderBannerPath;
	
	$fileIndexProfile = $_FILES['packageprofileimg'];
	$folderProfile =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/";
	$folderProfileView = "images/profile";
	$folderProfile .= $folderProfileView;
	$folderBannerProfile = ImgUpload($fileIndexProfile, $title, $folderProfile);
	$profile_img_path = $folderProfileView."/".$folderBannerProfile;
	
	$pakDetCode = $PackageControlDetail->insertCtrl($title, $short_decr, $start_date, $end_date, $available_seats, $duration, $price, $promotion_price, $deep_desc, $featured_video_link, $google_map_link, $package_cat_id, $cover_img_path, $profile_img_path);
	if($pakDetCode){
		echo '<script>window.location = "../manage-package-about-tour?pdcode='.$pakDetCode.'";</script>';
	}else{
		echo '<script>window.location = "../manage-package";</script>';
	}
}
?>