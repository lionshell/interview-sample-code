<?php
$domainURL = 'http://localhost/eagle/eagle';
?>