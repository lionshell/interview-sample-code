<?php

/* 
	Db Connection, Db connection close, and query execution
*/
class DB{
	// Db Connection function 
	public function dbConnection(){
		$db_host = 'localhost'; // Host name of Mysql Database
		$db_user = 'root'; // Host User name
		$db_pwd = ''; // Host user name password
		$db_name = 'eagle_tours'; // Database name
		
		// Creating db connection
		$conn = mysqli_connect($db_host, $db_user, $db_pwd, $db_name);
		//Return db connection
		return $conn;
	}
	// Db connection close function
	public function connectionClose(){
		// Creating db connection 
		$connDB = $this->DBConnection();
		// Creating db close connection 
		$connClose = mysqli_close($connDB);
		// Returning db connection close
		return $connClose;		
	}
	// Passing sql query to db
	public function excuteQuery($sqlQuery){
		// Creating db connection 
		$connDB = $this->DBConnection();
		// receiving sql query and creating connection with db to execute command
		$excuSqlQuery = mysqli_query($connDB, $sqlQuery);
		// Validating query successfully executed
		if($excuSqlQuery){
			return $excuSqlQuery; 
		}else{
			echo mysqli_error($connDB);
			echo "Unable to Execute the query.";
		}
		// Close db connection
		$this->connectionClose();		
	}
	// Passing sql query to db with require of last insert id
	public function excuteQueryWithLastInsertId($sqlQuery){
		// Creating db connection 
		$connDB = $this->DBConnection();
		// receiving sql query and creating connection with db to execute command
		$excuSqlQuery = mysqli_query($connDB, $sqlQuery);
		// Validating query successfully executed
		if($excuSqlQuery){
			return mysqli_insert_id($connDB); 
		}else{
			echo mysqli_error($connDB);
			echo "Unable to Execute the query.";
		}
		// Close db connection
		$this->connectionClose();		
	}
}
?>