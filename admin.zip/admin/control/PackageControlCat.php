<?php
include_once("../module/Package.php");

class PackageControlCat extends Package {
    // Insert package cat 
    public function insertCtrl($cat_type = "", $title = "", $decr = "", $img_path = "") {
        $this->addPackageCat($cat_type, $title, $decr, $img_path);
    }
    // View package cat
    public function viewCtrl($cat_type = "") {
        $Result = $this->viewPackageCat($cat_type);
        // 1 = No data, 2 = error on inserting
        if($Result === 1) {
            echo "No data available at the movement.";
        } else {
            // looping return comes from different class

            while($viewResult = mysqli_fetch_array($Result)) {
                echo "	
					<tr>
						<td>" . $viewResult['title'] . "</td>
						<td>" . $viewResult['decr'] . "</td>
						<td>" . $viewResult['img_path'] . "</td>
						<td><a href='edit-package-cat?cat=$cat_type&del=delcat&id=" . $viewResult['id'] . "'><span class='glyphicon glyphicon-pencil' aria-hidden='true'></span></a>
							<a href='manage-package-cat?cat=$cat_type&del=delcat&id=" . $viewResult['id'] . "'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a>" . $viewResult['id'] . "</td>
					</tr>
				";
            }
        }
    }
	// View package cat
    public function viewListCtrl() {
        $Result = $this->viewListPackageCat();
        // 1 = No data, 2 = error on inserting
        if($Result === 1) {
            echo "No data available at the movement.";
        } else {
            // looping return comes from different class
			$i = 0;	
            while($viewResult = mysqli_fetch_array($Result)) {
				if($i == 0){
					echo "<option selected value ='" . $viewResult['id'] . "'>" . $viewResult['title'] . "</option>";
				}else{
					echo "<option value ='" . $viewResult['id'] . "'>" . $viewResult['title'] . "</option>";
				}
                
            }
        }
    }
	// Edit package cat
    public function editCtrl($id = "") {
        $Result = $this->viewPackageCat($id);
        // 1 = No data, 2 = error on inserting
        if($Result === 1) {
            echo "No data available at the movement.";
        } else {
            // looping return comes from different class

            $viewResult = mysqli_fetch_array($Result);
			
			$resultId = $viewResult['id'];
			$resultCatType = $viewResult['cat_type'];
			$resultTitle = $viewResult['title'];
			$resultDecr = $viewResult['decr'];
			$resultImgPath = $viewResult['img_path'];
			
				
			echo "	<div class='row'>
							<div class='col-md-12'>
								<div>
									<label>Category Type</label>
								</div>
								<div class='input-group'>
								  <input type='text' class='form-control' value='$resultCatType'  aria-describedby='sizing-addon2' disabled>
								 
								  <input type='hidden' class='form-control' name='cat_type' value='$resultCatType'  aria-describedby='sizing-addon2' />
								  
								</div>
							</div>
							<div class='col-md-12'>
								<div>
									<label>Category Name</label>
								</div>
								<div class='input-group'>
								  <input type='text' class='form-control' name='cat_title' value='$resultTitle' placeholder='Category Name' aria-describedby='sizing-addon2'>
								</div>
							</div>
							<div class='col-md-12'>
								<div>
									<label>Category Description</label>
								</div>
								<div class='input-group'>
								  <textarea type='text' class='form-control' name='cat_desc' placeholder='Description' aria-describedby='sizing-addon2'>$resultDecr</textarea>
								</div>
							</div>
							<div class='col-md-12'>
								<div>
									<label>Cover Image</label>
								</div>
								<div class='input-group'>
								  <!--
								  <input type='text' class='custom-file-input' name='cat_cover_img' placeholder='Category Name' aria-describedby='sizing-addon2'>
								  -->
								  <input type='file' class='custom-file-input' name='cat_cover_img' placeholder='Category Name' aria-describedby='sizing-addon2'>
								</div>
							</div>
							<div class='col-md-12'>
								
								<div class='input-group'>
								  <input type='submit' class='btn btn-sm' name='editCat' aria-describedby='sizing-addon2' />
				
								</div>
							</div>
						</div>
				";
				
				
              
        }
    }
    // Delete package cat
    public function delCtrl($id = "", $cat_type = "") {
        $status = $this->delPackageCat($id);
		if($status == 1) {
        if($cat_type == "wild") {
			echo "<script>window.location ='manage-package-cat?cat=wild'</script>";
        } else if($cat_type == "std") {
			echo "<script>window.location ='manage-package-cat?cat=std'</script>";
        } else {
            echo "Something went wrong";
        }
    }
       // return $status;
    }
}

?>