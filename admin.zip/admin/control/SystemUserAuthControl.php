<?php

include_once("../module/SystemUserAuth.php");

class SystemUserAuthControl extends SystemUserAuth {
    // View package cat
    public function athourize($user_name = '' , $pwd = '') {
        $returnarr = array();
		$Result = $this->findSysUser($user_name , $pwd);
        // 1 = No data, 2 = error on inserting
        if($Result === 1) {
            $returnarr = array(1);
			return $returnarr;	
        } else {
            
			// looping return comes from different class
			$viewResult = mysqli_fetch_array($Result);
			if($viewResult){
				$returnarr = array(1, $viewResult[0]);
				return $returnarr;	
			}else{
				$returnarr = array(1);
				return $returnarr;	
			}
			
		}
    }
	// Validate user loged in 
    public function validate() {
		if(!isset($_SESSION['username'])){
			die('<script>window.location = "log-in";</script>');
		}   
    }
	// Validate user loged in 
    public function logout() {
		session_destroy();   
    }
}

?>