<?php
include_once("../module/Events.php");

class EventsControl extends Events {
    // Insert package Detail 
    public function addEventCtrl($evt_name ='', $evt_date ='', $evt_time ='', $evt_location ='', $evt_profile_img_path = '') {
		return $this->addEvent($evt_name, $evt_date, $evt_time, $evt_location, $evt_profile_img_path);
    }
    // View package cat
    public function viewEventCtrl() {
		$base_url = '';
        $Result = $this->viewEventList();
        // 1 = No data, 2 = error on inserting
        if($Result === 1) {
            echo "No data available at the movement.";
        } else {
            // looping return comes from different class

            while($viewResult = mysqli_fetch_array($Result)) {
                echo "	
					<tr>
						<td>" . $viewResult['id'] . "</td>
						<td>" . $viewResult['evt_name'] . "</td>
						<td>" . $viewResult['evt_date'] . "</td>
						<td>" . $viewResult['evt_time'] . "</td>
						<td>" . $viewResult['evt_location'] . "</td>
						<td>" .$base_url.$viewResult['evt_profile_img_path'] . "</td>
						<td><a href='edit-package-cat?del=delcat&id=" . $viewResult['id'] . "'><span class='glyphicon glyphicon-pencil' aria-hidden='true'></span></a>
							<a href='manage-package-cat?del=delcat&id=" . $viewResult['id'] . "'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a>" . $viewResult['id'] . "</td>
					</tr>
				";
            }
        }
    }
    
	// Edit package cat
    public function editCtrl($id = "") {
        $Result = $this->viewPackageCat($id);
        // 1 = No data, 2 = error on inserting
        if($Result === 1) {
            echo "No data available at the movement.";
        } else {
            // looping return comes from different class

            $viewResult = mysqli_fetch_array($Result);
			
			$resultId = $viewResult['id'];
			$resultCatType = $viewResult['cat_type'];
			$resultTitle = $viewResult['title'];
			$resultDecr = $viewResult['decr'];
			$resultImgPath = $viewResult['img_path'];
				
			echo "	<div class='row'>
							<div class='col-md-12'>
								<div>
									<label>Category Type</label>
								</div>
								<div class='input-group'>
								  <input type='text' class='form-control' value='$resultCatType'  aria-describedby='sizing-addon2' disabled>
								 
								  <input type='hidden' class='form-control' name='cat_type' value='$resultCatType'  aria-describedby='sizing-addon2' />
								  
								</div>
							</div>
							<div class='col-md-12'>
								<div>
									<label>Category Name</label>
								</div>
								<div class='input-group'>
								  <input type='text' class='form-control' name='cat_title' value='$resultTitle' placeholder='Category Name' aria-describedby='sizing-addon2'>
								</div>
							</div>
							<div class='col-md-12'>
								<div>
									<label>Category Description</label>
								</div>
								<div class='input-group'>
								  <textarea type='text' class='form-control' name='cat_desc' placeholder='Description' aria-describedby='sizing-addon2'>$resultDecr</textarea>
								</div>
							</div>
							<div class='col-md-12'>
								<div>
									<label>Cover Image</label>
								</div>
								<div class='input-group'>
								  <!--
								  <input type='text' class='custom-file-input' name='cat_cover_img' placeholder='Category Name' aria-describedby='sizing-addon2'>
								  -->
								  <input type='file' class='custom-file-input' name='cat_cover_img' placeholder='Category Name' aria-describedby='sizing-addon2'>
								</div>
							</div>
							<div class='col-md-12'>
								
								<div class='input-group'>
								  <input type='submit' class='btn btn-sm' name='editCat' aria-describedby='sizing-addon2' />
				
								</div>
							</div>
						</div>
				";
		}
    }
    // Delete package cat
    public function delCtrl($id = "", $cat_type = "") {
        $status = $this->delPackageCat($id);
		if($status == 1) {
			if($cat_type == "wild") {
				echo "<script>window.location ='manage-package-cat?cat=wild'</script>";
			} else if($cat_type == "std") {
				echo "<script>window.location ='manage-package-cat?cat=std'</script>";
			} else {
				echo "Something went wrong";
			}
		}
       // return $status;
    }
	
	function ImgUpload($fileIndex = "", $title = "", $folder = ""){
		$img_path_tempname = $fileIndex['tmp_name'];
		$img_path_name = $fileIndex['name'];
		$img_path_new_name = strtolower(str_replace(' ', '-', $title));
		$img_path_new_name = strtolower(str_replace('/', '-', $img_path_new_name));
		$img_path_ext = pathinfo($img_path_name, PATHINFO_EXTENSION);
		$img_path_new_name_store_db = "$img_path_new_name.$img_path_ext";
		move_uploaded_file($img_path_tempname, "$folder/$img_path_new_name.$img_path_ext");	
		//return $img_path_new_name_store_db;
		return $img_path_tempname;
	}
}

?>