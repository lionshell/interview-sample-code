<?php
include_once("../lib/DB.php");
/* 
	Add Package Cat, Delete Package Cat and View Package Cat
 */
class ImageUpload extends DB{
	// Executing query to add package cat in db
	public function __construct(){
		
	}
	public function imageUpload(){
		$errors= array();
		$file_name = $_FILES['image']['name'];
		$file_size =$_FILES['image']['size'];
		$file_tmp =$_FILES['image']['tmp_name'];
		$file_type=$_FILES['image']['type'];
		$uploadDir = "../img_upload/".$file_name;
		$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
		  
		$expensions= array("jpeg","jpg","png");
		  
		if(in_array($file_ext,$expensions)=== false){
			$errors[]="extension not allowed, please choose a JPEG or PNG file.";
		}
		  
		if($file_size > 2097152){
			$errors[]='File size must be excately 2 MB';
		}
		  
		if(empty($errors)==true){
			move_uploaded_file($file_tmp, $uploadDir);
			echo "Success";
		}else{
			print_r($errors);
		}
		
		$addPackageCatQuery = "INSERT INTO package_cat (cat_type, title, decr, img_path) values ('$cat_type', '$title', '$decr', '$img_path')"; // query
		$addPackageCatQuery = $this->excuteQuery($addPackageCatQuery); // Executing query for db
		if($addPackageCatQuery){
			return 1; // if query execution success will return 1
		}else{
			return 2; // On fail will return 2
		}
	}
	public function viewPackageCat($cat_type=""){
		$viewPackageCatQuery = "SELECT * FROM package_cat WHERE cat_type = '$cat_type'"; // query
		$resut = $this->excuteQuery($viewPackageCatQuery);// Executing query for db
		if($resut){
			$rowCount = mysqli_num_rows($resut);
			if($rowCount > 0){
				return $resut; // if query execution success will return result object	
			}else{
				return 1;
			}			
		}else{
			return 2;
		}
	}
	public function delPackageCat($id){
		$delPackageCatQuery = "DELETE FROM package_cat WHERE id = '$id'"; // query
		$packDel = $this->excuteQuery($delPackageCatQuery);// Executing query for db
		if($packDel){
			return 1; // if query execution success will return 1
		}else{
			return 2;
		}	
	}
}
?>