<?php
include_once("../lib/DB.php");

/*
 Add Package Cat, Delete Package Cat and View Package Cat
 */

class Package extends DB {
    // Executing query to add package cat in db
    public function addPackageCat($cat_type = "", $title = "", $decr = "", $img_path = "") {
        $addPackageCatQuery = "INSERT INTO package_cat (cat_type, title, decr, img_path) values ('$cat_type', '$title', '$decr', '$img_path')";
        // query
        $addPackageCatQuery = $this->excuteQuery($addPackageCatQuery);
        // Executing query for db
        if($addPackageCatQuery) {
            // if query execution success will return 1
            return 1;
        } else {
            // On fail will return 2
            return 2;
        }
    }
    // Executing query to create view
    public function viewPackageCat($cat_type = "") {
        $viewPackageCatQuery = "SELECT * FROM package_cat WHERE cat_type = '$cat_type'";
        // query
        $resut = $this->excuteQuery($viewPackageCatQuery);
        // Executing query for db
        if($resut) {
            $rowCount = mysqli_num_rows($resut);
            if($rowCount > 0) {
                return $resut;
                // if query execution success will return result object	
            } else {
                return 1;
            }
        } else {
            return 2;
        }
    }
	// Executing query to create view
    public function viewListPackageCat() {
        $viewPackageCatQuery = "SELECT * FROM package_cat";
        // query
        $resut = $this->excuteQuery($viewPackageCatQuery);
        // Executing query for db
        if($resut) {
            $rowCount = mysqli_num_rows($resut);
            if($rowCount > 0) {
                return $resut;
                // if query execution success will return result object	
            } else {
                return 1;
            }
        } else {
            return 2;
        }
    }
    // Executing query to delete package cat from db
    public function delPackageCat($id) {
        /*
         * Image delete process
         */
        // holding status about file status
        $fileStatus = true;
        // Sql query to find image name from db
        $imgPathFinderSql = "SELECT img_path FROM package_cat WHERE id = '$id'";
        // Executting query to find img path
        $imgPathSqlObject = $this->excuteQuery($imgPathFinderSql);
        // holding return of sql object
        $imgDetTarget = mysqli_fetch_array($imgPathSqlObject);
        // extract image name
        $imgPathFile = $imgDetTarget['img_path'];
        // adding root path to image file 
        $imgDetTargetFile = $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/images/cat_cover_img/$imgPathFile";
        // Checking file excistence
        if(file_exists($imgDetTargetFile)) {
            // Deleting file from server
            unlink($imgDetTargetFile);
            //changing value to true, make file has removed
        }
        //}
        /*
         * Codes to delete data from db
         */
        //once file has deleted from server, this code will execute         
        if($fileStatus == true) {
            // query            
            $delPackageCatQuery = "DELETE FROM package_cat WHERE id = '$id'";
            // Executing query for db
            $packDel = $this->excuteQuery($delPackageCatQuery);
            if($packDel) {
                // if query execution success will return 1
		         return 1;
            } else {
		        return 2;
            }
        }
    }
}

?>