<?php
include_once("../lib/DB.php");

/*
 Add Package Detail, Delete Package Detail and View Package Detail
 */

class PackageDetail extends DB {
    // Executing query to add package detail in db
    public function addPackageDetail($title = "", $short_decr = "", $start_date = "", $end_date = "", $available_seats = "", $duration = "", $price = "", $promotion_price = "", $deep_desc = "", $featured_video_link = "", $google_map_link = "", $package_cat_id = "", $cover_img_path = "", $profile_img_path = "") {
       // $addPackageDetailQuery = "INSERT INTO `package_details` (`title`, `short_decr`, `start_date`, `end_date`, `available_seats`, `duration`, `price`, `promotion_price`, `deep_desc`, `featured_video_link`, `cover_img_path`, `profile_img_path`, `package_cat_id`) values ('$title', '$short_decr', '$start_date', '$end_date', '$available_seats', '$duration', '$price', '$promotion_price', '$deep_desc', '$featured_video_link', '$cover_img_path', '$profile_img_path', '$package_cat_id')";
       $addPackageDetailQuery = "INSERT INTO `package_details`(`title`, `short_decr`, `start_date`, `end_date`, `available_seats`, `duration`, `price`, `promotion_price`, `deep_desc`, `featured_video_link`, `google_map_link`, `cover_img_path`, `profile_img_path`, `package_cat_id`) values ('$title', '$short_decr', '$start_date', '$end_date', '$available_seats', '$duration', '$price', '$promotion_price', '$deep_desc', '$featured_video_link', '$google_map_link', '$cover_img_path', '$profile_img_path', '$package_cat_id')";
     	// query
        $addPackageDetailQuery = $this->excuteQueryWithLastInsertId($addPackageDetailQuery);
        // Executing query for db
        if($addPackageDetailQuery) {
            // if query execution success will return last inserted record id
            return $addPackageDetailQuery;
        } else {
            // On fail will return 2
            return 2;
        }
    }
	// Executing query to add package detail day in db
    public function addPackageDetailDay($heading = "", $description = "", $pdcode = "") {
       $addPackageDetailDayQuery = "INSERT INTO pac_dtled_day_wise_itry(heading, content, package_details_id) VALUES ('$heading','$description','$pdcode')";
     	// query
        $addPackageDetailDayQuery = $this->excuteQueryWithLastInsertId($addPackageDetailDayQuery);
        // Executing query for db
        if($addPackageDetailDayQuery) {
            // if query execution success will return last inserted record id
            return 1;
        } else {
            // On fail will return 2
            return 2;
        }
    }
	// Executing query to add package about detail in db
    public function addPackageAboutDetail($placecoverd = "", $inclusions = "", $exclustions = "", $eventdate = "", $packagedetailsid = "") {
       $addPackageAboutDetailQuery = "INSERT INTO pac_abt_tour(place_coverd, inclusions, exclustions, event_date, package_details_id) VALUES ('$placecoverd','$inclusions','$exclustions','$eventdate','$packagedetailsid')";
     	// query
        $addPackageAboutDetailQuery = $this->excuteQueryWithLastInsertId($addPackageAboutDetailQuery);
        // Executing query for db
        if($addPackageAboutDetailQuery) {
            // if query execution success will return last inserted record id
            return 1;
        } else {
            // On fail will return 2
            return 2;
        }
    }
	// Executing query to add package gallery in db
    public function addGallery($img_path = "", $package_details_id = "") {
       $addGalleryQuery = "INSERT INTO gallery(img_path, package_details_id) VALUES ('$img_path','$package_details_id')";
     	// query
        $addGalleryQuery = $this->excuteQueryWithLastInsertId($addGalleryQuery);
        // Executing query for db
        if($addGalleryQuery) {
            // if query execution success will return last inserted record id
            return 1;
        } else {
            // On fail will return 2
            return 2;
        }
    }
    // Executing query to create view
    public function getPackageTitle($packagedetailsid = ""){
        $getPackageTitleQuery = "SELECT title FROM package_details WHERE id = '$packagedetailsid'";
        // query
        $resut = $this->excuteQuery($getPackageTitleQuery);
        // Executing query for db
        if($resut) {
            $rowCount = mysqli_num_rows($resut);
            if($rowCount > 0) {
                return $resut;
                // if query execution success will return result object	
            } else {
                return 1;
            }
        } else {
            return 2;
        }
    }
    // Executing query to create view
    public function viewPackageDetail($cat_type = "") {
        $viewPackageDetailQuery = "SELECT * FROM package_cat WHERE cat_type = '$cat_type'";
        // query
        $resut = $this->excuteQuery($viewPackageDetailQuery);
        // Executing query for db
        if($resut) {
            $rowCount = mysqli_num_rows($resut);
            if($rowCount > 0) {
                return $resut;
                // if query execution success will return result object	
            } else {
                return 1;
            }
        } else {
            return 2;
        }
    }
    // Executing query to delete package detail from db
    public function delPackageDetail($id) {
        /*
         * Image delete process
         */
        // holding status about file status
        $fileStatus = true;
        // Sql query to find image name from db
        $imgPathFinderSql = "SELECT img_path FROM package_cat WHERE id = '$id'";
        // Executting query to find img path
        $imgPathSqlObject = $this->excuteQuery($imgPathFinderSql);
        // holding return of sql object
        $imgDetTarget = mysqli_fetch_array($imgPathSqlObject);
        // extract image name
        $imgPathFile = $imgDetTarget['img_path'];
        // adding root path to image file 
        $imgDetTargetFile = $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/images/cat_cover_img/$imgPathFile";
        // Checking file excistence
        if(file_exists($imgDetTargetFile)) {
            // Deleting file from server
            unlink($imgDetTargetFile);
            //changing value to true, make file has removed
        }
        //}
        /*
         * Codes to delete data from db
         */
        //once file has deleted from server, this code will execute         
        if($fileStatus == true) {
            // query            
            $delPackageDetailQuery = "DELETE FROM package_cat WHERE id = '$id'";
            // Executing query for db
            $packDel = $this->excuteQuery($delPackageCatQuery);
            if($packDel) {
                // if query execution success will return 1
		         return 1;
            } else {
		        return 2;
            }
        }
    }
}

?>