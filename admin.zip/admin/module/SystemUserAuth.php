<?php
include_once("../lib/DB.php");

/*
 Add Package Detail, Delete Package Detail and View Package Detail
 */

class SystemUserAuth extends DB {
    // Executing query to create view
     public function findSysUser($user_name = "", $pwd = "") {
       // $addPackageDetailQuery = "INSERT INTO `package_details` (`title`, `short_decr`, `start_date`, `end_date`, `available_seats`, `duration`, `price`, `promotion_price`, `deep_desc`, `featured_video_link`, `cover_img_path`, `profile_img_path`, `package_cat_id`) values ('$title', '$short_decr', '$start_date', '$end_date', '$available_seats', '$duration', '$price', '$promotion_price', '$deep_desc', '$featured_video_link', '$cover_img_path', '$profile_img_path', '$package_cat_id')";
       $getPackageTitleQuery = "SELECT * FROM sys_users_eagle WHERE sys_user_name = $user_name AND sys_user_pwd = $pwd AND sys_staus = 1";
        // query
        $resut = $this->excuteQuery($getPackageTitleQuery);
        // Executing query for db
        if($resut) {
            $rowCount = mysqli_num_rows($resut);
            if($rowCount > 0) {
                return $resut;
                // if query execution success will return result object	
            } else {
                return 1;
            }
        } else {
            return 2;
        }
    }
}

?>