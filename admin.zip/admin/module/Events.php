<?php
include_once("../lib/DB.php");

/*
 Add Package Cat, Delete Package Cat and View Package Cat
 */

class Events extends DB {
    // Executing query to add package cat in db
    public function addEvent($evt_name ='', $evt_date ='', $evt_time ='', $evt_location ='', $evt_profile_img_path) {
        $addPackageCatQuery = "INSERT INTO events(evt_name, evt_date, evt_time, evt_location, evt_profile_img_path) VALUES ('$evt_name','$evt_date','$evt_time','$evt_location','$evt_profile_img_path')";
        // query
        $addPackageCatQuery = $this->excuteQuery($addPackageCatQuery);
        // Executing query for db
        if($addPackageCatQuery) {
            // if query execution success will return 1
            return 1;
        } else {
            // On fail will return 2
            return 2;
        }
    }
    // Executing query to create view
    public function viewEventList() {
        $viewPackageCatQuery = "SELECT * FROM events";
        // query
        $resut = $this->excuteQuery($viewPackageCatQuery);
        // Executing query for db
        if($resut) {
            $rowCount = mysqli_num_rows($resut);
            if($rowCount > 0) {
                return $resut;
                // if query execution success will return result object	
            } else {
                return 1;
            }
        } else {
            return 2;
        }
    }
	
    // Executing query to delete package cat from db
    public function delEvent($id) {
		$delPackageCatQuery = "DELETE FROM package_cat WHERE id = '$id'";
        $packDel = $this->excuteQuery($delPackageCatQuery);
            if($packDel) {
                // if query execution success will return 1
		         return 1;
            } else {
		        return 2;
            }
	}
}

?>