<?php
	session_start();
	ob_start();
	$pageTitle = 'Eagle Admin Panel';
	include_once('../control/SystemUserAuthControl.php');
	$SystemUserAuthControl = new SystemUserAuthControl();
	$SystemUserAuthControl->validate();
	$pageTitle = 'Eagle Admin Panel';
	include_once('../lib/system-info.php');
	include_once('../control/PackageControlCat.php');
	$ctrl = new PackageControlCat;

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<?php
			include_once('../include/header.php');
		?>
	</head>
	<body>
		<div class="eagle-admin-nav">
			<nav class="navbar navbar-default navbar-fixed-top">
				<?php
					include_once('../include/nav.php');
				?>  
			</nav>
		</div>
		
		<div class="eagle-admin-body">
		
			<div class="container-fluid">
			
				<div class="page-edit-container m-t-5 m-b-10">
				
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item active" aria-current="page">Add Package</li>
					<!-- <li class="breadcrumb-item"><a href="#">Library</a></li> -->
				  </ol>
				</nav>
					<!-- Form that contain information to edit the page. -->
					<form action="process/process-manage-package.php" enctype="multipart/form-data" method="POST">
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Type</label>
							</div>
							<div class="col-md-8">
								<input  type="text" class="form-control" placeholder="Package Type" aria-describedby="sizing-addon2" disabled value="std" />
								<input  type="hidden" class="form-control" placeholder="Package Type" name="packagetype" aria-describedby="sizing-addon2" value="std" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Cat</label>
							</div>
							<div class="col-md-8">
								<select class="form-control" name="packagecat">
									<?php 
									$ctrl->viewListCtrl(); 
									?>
								</select>
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Name</label>
							</div>
							<div class="col-md-8">
							  <input type="text" class="form-control" placeholder="Package Name" name="packagename" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Price</label>
							</div>
							<div class="col-md-8">
							  <input type="text" class="form-control" placeholder="Package Price" name="packageprice" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Promotion Price</label>
							</div>
							<div class="col-md-8">
							  <input type="text" class="form-control" placeholder="Package Promotion Price" name="packagepromotionprice" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Duration</label>
							</div>
							<div class="col-md-8">
							  <input type="text" class="form-control" placeholder="Package Duration" name="packageduration" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Short Description</label>
							</div>
							<div class="col-md-8">
								<input type="text" class="form-control" placeholder="Package Short Description" name="packageshortdescription" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Description</label>
							</div>
							<div class="col-md-8">
							  <input type="text" class="form-control" placeholder="Package Description" name="packagedescription" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Available Seats</label>
							</div>
							<div class="col-md-8">
							  <input type="number" class="form-control" placeholder="Available Seats" name="packageavalibleseats" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Featured Video Link (from youtube.com)</label>
							</div>
							<div class="col-md-8">
							  <input type="text" class="form-control" placeholder="Featured Video Link (from youtube.com)" name="packagefeaturedvideolink" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Start Date</label>
							</div>
							<div class="col-md-8">
							  <input type="date" class="form-control" placeholder="Start Date" name="packagestartdate" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>End Date</label>
							</div>
							<div class="col-md-8">
							  <input type="date" class="form-control" placeholder="End Date" name="packageenddate" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Locations view in Google Map</label>
							</div>
							<div class="col-md-8">
								<input type="text" class="" placeholder="Past link here" name="packagemaplink" aria-describedby="sizing-addon2" value="" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Banner Image (Image W * H : 1350 * 500)</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="" placeholder="Package Banner Image" name="packagebannerimg" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Profile Image (Image W * H : 550 * 353)</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="" placeholder="Package Profile Image" name="packageprofileimg" aria-describedby="sizing-addon2" />
							</div>
						</div>
						
					<!--
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Package Locations (Location separate by ",")</label>
							</div>
							<div class="col-md-8">
							  <input type="text" class="form-control" placeholder="Package Locations" name="packagelocations" aria-describedby="sizing-addon2" />
							</div>
						</div>
						
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Photo Gallery (Image W * H : 850 * 450)</label>
							</div>
							<div class="col-md-8">
								<input type="file" class="" placeholder="Package Gallery Image" name="packagegalleryimg" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Locations view in Google Map</label>
							</div>
							<div class="col-md-8">
								<input type="text" class="" placeholder="Past link here" name="packagemaplink" aria-describedby="sizing-addon2" value="" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>About tours</label>
							</div>
							<div class="col-md-8">
								<input type="text" class="" placeholder="Past link here" name="packageCoverImage" aria-describedby="sizing-addon2" value="" />
								<input type="button" class="" placeholder="Package Cover Image" name="packageCoverImage" aria-describedby="sizing-addon2" value="Add More" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Detailed Day Wise Itinerary</label>
							</div>
							<div class="col-md-8">
								<span>Day 01</span>
								<input type="text" class="" placeholder="Package Cover Image" name="packageCoverImage" aria-describedby="sizing-addon2" value="" />
								<input type="button" class="" placeholder="Package Cover Image" name="packageCoverImage" aria-describedby="sizing-addon2" value="Add More" />
							</div>
						</div>
				-->
						<div class="row m-b-5">
							<button type="submit" value="save" name="save">Save Changes</button>
						</div>
						
					</form>
					<!-- ./Form that contain information to edit the page. -->
				</div>
				 
			</div>
		</div>
		<div class="eagle-admin-footer">
			<footer class="footer">
				<?php
					include_once('../include/footer.php');
				?>
			</footer>
		</div>
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>
<?php
	ob_end_flush();
?>