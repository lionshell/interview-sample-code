<?php
session_start();
ob_start();
$pageTitle = 'Eagle Admin Panel';
include_once('../control/SystemUserAuthControl.php');
$SystemUserAuthControl = new SystemUserAuthControl();
$SystemUserAuthControl->validate();

$pageTitle = 'Eagle Admin Panel';
include_once('../lib/system-info.php');
include_once('../control/authorize.php');
include_once('../control/PackageControlCat.php');
$ctrl = new PackageControlCat;
$pdcode = $_GET['pdcode'];
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<?php
			include('../include/header.php');
		?>
	</head>
	<body>
		<div class="eagle-admin-nav">
			<nav class="navbar navbar-default navbar-fixed-top">
				<?php
					include('../include/nav.php');
				?>  
			</nav>
		</div>
		<div class="eagle-admin-body">
			<div class="container-fluid">
				<div class="page-edit-container m-t-5 m-b-10">
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item">Add Package</li>
					<li class="breadcrumb-item active" aria-current="page">Add About Tour</a></li> 
				  </ol>
				</nav>
					<!-- Form that contain information to edit the page. -->
					<form class='par-form' action="process/process-manage-package-about-tour.php" enctype="multipart/form-data" method="POST">
					<div class="par-form">
						<div class="form-abt m-b-15">
							<input type="hidden" name="pdcode[]" value="<?=$pdcode;?>"/>
							<div class="row m-b-5">
								<div class="col-md-4 label-input">
									<label>Place Coverd</label>
								</div>
								<div class="col-md-8">
								  <input type="text" class="form-control" placeholder="Package Name" name="placecoverd[]" aria-describedby="sizing-addon2" />
								</div>
							</div>
							<div class="row m-b-5">
								<div class="col-md-4 label-input">
									<label>Inclusions</label>
								</div>
								<div class="col-md-8">
								  <input type="text" class="form-control" placeholder="Package Duration" name="inclusions[]" aria-describedby="sizing-addon2" />
								</div>
							</div>
							<div class="row m-b-5">
								<div class="col-md-4 label-input">
									<label>Exclustions</label>
								</div>
								<div class="col-md-8">
								  <input type="text" class="form-control" placeholder="Package Duration" name="exclustions[]" aria-describedby="sizing-addon2" />
								</div>
							</div>
							<div class="row m-b-5">
								<div class="col-md-4 label-input">
									<label>Event Date</label>
								</div>
								<div class="col-md-8">
								  <input type="date" class="form-control" placeholder="Package Duration" name="eventdate[]" aria-describedby="sizing-addon2" />
								</div>
							</div>
						</div>
					</div>
					<div class="row m-b-5">
							<button type="button" class="addMore">Add More</button>
						</div>
						<div class="row m-b-5">
							<button type="submit" value="save" name="save">Save Changes</button>
						</div>
					</form>
					<!-- ./Form that contain information to edit the page. -->
				</div>
				 
			</div>
		</div>
		<div class="eagle-admin-footer">
			<footer class="footer">
				<?php
					include('../include/footer.php');
				?>
			</footer>
		</div>
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
		<script>
			$(document).ready(function(){
			 $('.addMore').click(function(){
			  // Create clone of <div class='input-form'>
			  var newel = $('.form-abt:last').clone();
			  // Add after last <div class='input-form'>
			  $(newel).insertAfter(".form-abt:last");
			 });
			});
		</script>
	</body>
</html>
<?php
	ob_end_flush();
?>