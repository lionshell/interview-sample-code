<?php
session_start();
$pageTitle = 'Eagle Admin Panel';
include_once('../control/SystemUserAuthControl.php');
$SystemUserAuthControl = new SystemUserAuthControl();
$SystemUserAuthControl->validate();
$pageTitle = 'Eagle Admin Panel';
//$pageCat = $_GET['cat'];
//$pageCat = $_GET['cat'];
include_once('../lib/system-info.php');
include_once('../process/process-image-upload.php');
include_once('../control/EventsControl.php');
$evtCtrl = new EventsControl();
if(isset($_POST['saveCat'])) {
    $evt_name = $_POST['evt-name'];
    $evt_date = $_POST['evt-date'];
    $evt_time = $_POST['evt-time'];
    $evt_location = $_POST['evt-location'];
    $fileIndex = $_FILES['evt-profile-img'];
	
	$folderBanner =  $_SERVER['DOCUMENT_ROOT'] . "/eagle/eagle/";
	$folderBannerView = "images/events";
	$folderBanner .= $folderBannerView;        
	$imgName = ImgUpload($fileIndex, $evt_name, $folderBanner);
	$evt_profile_img_path_new = $folderBannerView.'/'.$imgName;
    $evtCtrl->addEventCtrl($evt_name, $evt_date, $evt_time, $evt_location, $evt_profile_img_path_new);
}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<?php
include_once('../include/header.php');

?>
	</head>
	<body>
		<div class="eagle-admin-nav">
			<nav class="navbar navbar-default navbar-fixed-top">
				<?php
include_once('../include/nav.php');

?>  
			</nav>
		</div>
		<div class="eagle-admin-body">
			<div class="eagle-bread-crumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li><a href="#">Standard Package</a></li>
				  <li class="active">Edit Package Cat</li>
				</ol>
			</div>
			<div class="container-fluid">
				<div class="page-edit-container m-t-5 m-b-10">
					<!-- Form that contain information to edit the page. -->
					<form enctype="multipart/form-data" method="POST">
						<div class="row">
							
							<div class="col-md-12">
								<div>
									<label>Event Name</label>
								</div>
								<div class="input-group">
								  <input type="text" class="form-control" name="evt-name" placeholder="Event Name" aria-describedby="sizing-addon2">
								</div>
							</div>
							<div class="col-md-12">
								<div>
									<label>Date</label>
								</div>
								<div class="input-group">
								  <input type="date" class="form-control" placeholder="Event Date" name="evt-date" aria-describedby="sizing-addon2" />
								</div>
							</div>
							<div class="col-md-12">
								<div>
									<label>Time</label>
								</div>
								<div class="input-group">
								  <!--
								  <input type="text" class="custom-file-input" name="cat_cover_img" placeholder="Category Name" aria-describedby="sizing-addon2">
								  -->
								  <input type="time" class="custom-file-input" name="evt-time" placeholder="Event Time" aria-describedby="sizing-addon2">
								</div>
							</div>
							<div class="col-md-12">
								<div>
									<label>Location</label>
								</div>
								<div class="input-group">
								  <!--
								  <input type="text" class="custom-file-input" name="cat_cover_img" placeholder="Category Name" aria-describedby="sizing-addon2">
								  -->
								  <input type="text" class="custom-file-input" name="evt-location" placeholder="Event Location" aria-describedby="sizing-addon2">
								</div>
							</div>
							<div class="col-md-12">
								<div>
									<label>Image</label>
								</div>
								<div class="input-group">
								  <!--
								  <input type="text" class="custom-file-input" name="cat_cover_img" placeholder="Category Name" aria-describedby="sizing-addon2">
								  -->
								  <input type="file" class="custom-file-input" name="evt-profile-img" placeholder="Event Profile Picture" aria-describedby="sizing-addon2">
								</div>
							</div>
							<div class="col-md-12">
								
								<div class="input-group">
								  <input type="submit" class="btn btn-sm" name="saveCat" aria-describedby="sizing-addon2" value="Add Events" />
								 <!-- <input type="file" class="custom-file-input" name="<?= $pageCat;
?>_cat_cover_img" placeholder="Category Name" aria-describedby="sizing-addon2"> -->
								</div>
							</div>
						</div>
					</form>
					
					
					<!-- ./Form that contain information to edit the page. -->
				</div>
				<div class="cat-detail-table">
					<table class="table table-striped">
					
						<tr>
							<td>#</td>
							<td>Name</td>
							<td>Date</td>
							<td>Time</td>
							<td>Location</td>
							<td>Cover Image</td>
							<td>Action</td>
						</tr>
						<tbody>
						<?php
						$evtCtrl->viewEventCtrl();
						?>
						</tbody>
					</table>
				</div>
				 
			</div>
		</div>
		<div class="eagle-admin-footer">
			<footer class="footer">
				<?php
include_once('../include/footer.php');

?>
			</footer>
		</div>
		
		
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>