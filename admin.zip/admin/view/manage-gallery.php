<?php
session_start();
ob_start();
$pageTitle = 'Eagle Admin Panel';
include_once('../control/SystemUserAuthControl.php');
$SystemUserAuthControl = new SystemUserAuthControl();
$SystemUserAuthControl->validate();

$pageTitle = 'Eagle Admin Panel';
include_once('../lib/system-info.php');
include_once('../control/authorize.php');
include_once('../control/PackageControlCat.php');
$ctrl = new PackageControlCat;
$pdcode = $_GET['pdcode'];
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<?php
			include('../include/header.php');
		?>
	</head>
	<body>
		<div class="eagle-admin-nav">
			<nav class="navbar navbar-default navbar-fixed-top">
				<?php
					include('../include/nav.php');
				?>  
			</nav>
		</div>
		<div class="eagle-admin-body">
			<div class="container-fluid">
				<div class="page-edit-container m-t-5 m-b-10">
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item">Add Package</li>
					<li class="breadcrumb-item">Add About Tour</a></li> 
					<li class="breadcrumb-item">Add Day Details</a></li> 
					<li class="breadcrumb-item active" aria-current="page">Add Gallery</a></li> 
				  </ol>
				</nav>
					<!-- Form that contain information to edit the page. -->
					<form action="process/process-manage-gallery.php" enctype="multipart/form-data" method="POST">
						<input type="hidden" name="pdcode" value="<?=$pdcode;?>"/>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image size w:850 * h:450</label>
							</div>
							
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 01</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 01" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 02</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 02" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 03</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 03" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 04</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 04" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 05</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 05" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 06</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 06" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 07</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 07" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 08</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 08" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 09</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 09" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 10</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 10" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 11</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 11" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<div class="col-md-4 label-input">
								<label>Image 12</label>
							</div>
							<div class="col-md-8">
							  <input type="file" class="form-control" placeholder="Image 12" name="gallery[]" aria-describedby="sizing-addon2" />
							</div>
						</div>
						<div class="row m-b-5">
							<button type="submit" value="save" name="save">Save Changes</button>
						</div>
					</form>
					<!-- ./Form that contain information to edit the page. -->
				</div>
				 
			</div>
		</div>
		<div class="eagle-admin-footer">
			<footer class="footer">
				<?php
					include('../include/footer.php');
				?>
			</footer>
		</div>
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>
<?php
	ob_end_flush();
?>