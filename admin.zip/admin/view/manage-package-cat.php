<?php
session_start();
$pageTitle = 'Eagle Admin Panel';
include_once('../control/SystemUserAuthControl.php');
$SystemUserAuthControl = new SystemUserAuthControl();
$SystemUserAuthControl->validate();
$pageTitle = 'Eagle Admin Panel';
$pageCat = $_GET['cat'];
//$pageCat = $_GET['cat'];
include_once('../lib/system-info.php');
include_once('../control/PackageControlCat.php');
$ctrl = new PackageControlCat;

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<?php
			include_once('../include/header.php');
		?>
	</head>
	<body>
		<div class="eagle-admin-nav">
			<nav class="navbar navbar-default navbar-fixed-top">
				<?php
					include_once('../include/nav.php');
				?>  
			</nav>
		</div>
		<div class="eagle-admin-body">
			<div class="eagle-bread-crumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li><a href="#">Standard Package</a></li>
				  <li class="active">Add Package Cat</li>
				</ol>
			</div>
			<div class="container-fluid">
				<div class="page-edit-container m-t-5 m-b-10">
					<!-- Form that contain information to edit the page. -->
					<form action="process/process-manage-package-cat.php" enctype="multipart/form-data" method="POST">
						<div class="row">
							<div class="col-md-12">
								<div>
									<label>Category Type</label>
								</div>
								<div class="input-group">
								  <input type="text" class="form-control" value="<?= $pageCat;
?>"  aria-describedby="sizing-addon2" disabled>
								 
								  <input type="hidden" class="form-control" name="cat_type" value="<?= $pageCat;
?>"  aria-describedby="sizing-addon2" />
								  
								</div>
							</div>
							<div class="col-md-12">
								<div>
									<label>Category Name</label>
								</div>
								<div class="input-group">
								  <input type="text" class="form-control" name="cat_title" placeholder="Category Name" aria-describedby="sizing-addon2">
								</div>
							</div>
							<div class="col-md-12">
								<div>
									<label>Category Description</label>
								</div>
								<div class="input-group">
								  <textarea type="text" class="form-control" name="cat_desc" placeholder="Description" aria-describedby="sizing-addon2"></textarea>
								</div>
							</div>
							<div class="col-md-12">
								<div>
									<label>Cover Image</label>
								</div>
								<div class="input-group">
								  <!--
								  <input type="text" class="custom-file-input" name="cat_cover_img" placeholder="Category Name" aria-describedby="sizing-addon2">
								  -->
								  <input type="file" class="custom-file-input" name="cat_cover_img" placeholder="Category Name" aria-describedby="sizing-addon2">
								</div>
							</div>
							<div class="col-md-12">
								
								<div class="input-group">
								  <input type="submit" class="btn btn-sm" name="saveCat" aria-describedby="sizing-addon2" value="Add Package Cat" />
								 <!-- <input type="file" class="custom-file-input" name="<?= $pageCat;
?>_cat_cover_img" placeholder="Category Name" aria-describedby="sizing-addon2"> -->
								</div>
							</div>
						</div>
					</form>
					
					
					<!-- ./Form that contain information to edit the page. -->
				</div>
				<div class="cat-detail-table">
					<table class="table table-striped">
					
						<tr>
							<td>Title</td>
							<td>Description</td>
							<td>Image Name</td>
							<td>Action</td>
						</tr>
						<tbody>
							<?php
$ctrl->viewCtrl($pageCat);

?>
						</tbody>
					</table>
				</div>
				 
			</div>
		</div>
		<div class="eagle-admin-footer">
			<footer class="footer">
				<?php
include_once('../include/footer.php');

?>
			</footer>
		</div>
		
		
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>