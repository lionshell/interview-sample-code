<?php
session_start();
ob_start();
$pageTitle = 'Eagle Admin Panel';
include_once('../control/SystemUserAuthControl.php');
$SystemUserAuthControl = new SystemUserAuthControl();
$SystemUserAuthControl->validate();

$pageTitle = 'Eagle Admin Panel';
include_once('../lib/system-info.php');
include_once('../control/authorize.php');
include_once('../control/PackageControlCat.php');
$ctrl = new PackageControlCat;

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<?php
			include_once('../include/header.php');
		?>
	</head>
	<body>
		<div class="eagle-admin-nav">
			<nav class="navbar navbar-default navbar-fixed-top">
				<?php
					include_once('../include/nav.php');
				?>  
			</nav>
		</div>
		<div class="eagle-admin-body">
			<div class="container-fluid">
				<div class="page-edit-container m-t-5 m-b-10">
					<table class="table table-sm">
					  <thead>
						<tr>
						  <th scope="col">#</th>
						  <th scope="col">Package Name</th>
						  <th scope="col">Package Cat</th>
						  <th scope="col">Actions</th>
						</tr>
					  </thead>
					  <tbody>
						<tr>
						  <th scope="row">1</th>
						  <td>Mark</td>
						  <td>Otto</td>
						  <td><span class="glyphicon glyphicon glyphicon-pencil" aria-hidden="true"></span><span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span></td>
						</tr>
						<tr>
						  <th scope="row">2</th>
						  <td>Jacob</td>
						  <td>Thornton</td>
						  <td>@fat</td>
						</tr>
						<tr>
						  <th scope="row">3</th>
						  <td colspan="2">Larry the Bird</td>
						  <td>@twitter</td>
						</tr>
					  </tbody>
					</table>
				</div>
				 
			</div>
		</div>
		<div class="eagle-admin-footer">
			<footer class="footer">
				<?php
					include_once('../include/footer.php');
				?>
			</footer>
		</div>
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>
<?php
	ob_end_flush();
?>