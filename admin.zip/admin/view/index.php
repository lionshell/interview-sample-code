<?php
	session_start();
	$pageTitle = 'Eagle Admin Panel';
	include_once('../control/SystemUserAuthControl.php');
	$SystemUserAuthControl = new SystemUserAuthControl();
	$SystemUserAuthControl->validate();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<?php
			include_once('../include/header.php');
		?>
	</head>
	<body>
		<div class="eagle-admin-nav">
			<nav class="navbar navbar-default navbar-fixed-top">
				<?php
					include_once('../include/nav.php');
				?>  
			</nav>
		</div>
		<div class="eagle-admin-body">
			<div class="container-fluid">
				
			</div>
		</div>
		<div class="eagle-admin-footer">
			<footer class="footer">
				<?php
					include_once('../include/footer.php');
				?>
			</footer>
		</div>
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>